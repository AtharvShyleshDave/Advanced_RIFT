#pragma once
#include <Arduino.h>

struct RFLinkStats {
  float pdr;
  float loss;
  uint16_t tx_ok;
  uint16_t rx_count;
  uint16_t packets;
};

static inline RFLinkStats stage1_make_stats(uint16_t tx_ok, uint16_t rx_count, uint16_t packets) {
  RFLinkStats s{};
  s.tx_ok=tx_ok; s.rx_count=rx_count; s.packets=packets;
  s.pdr = packets ? (float)tx_ok/(float)packets : 0.0f;
  s.loss = 1.0f-s.pdr;
  return s;
}
