#pragma once
#include <Arduino.h>
#include <math.h>

#define STAGE3_N_FEATURES 46

// Deployment Stage-3 representation. AC and BD are the two observed links.
// The remaining link slots are left as NAN and are imputed by Stage 6.
static inline void stage3_build_46_features(
    float x[STAGE3_N_FEATURES],
    float ac_pdr, uint16_t ac_packets,
    float bd_pdr, uint16_t bd_packets) {
  for (int i=0;i<STAGE3_N_FEATURES;i++) x[i]=NAN;

  // Link slot 1: AC
  x[0]=0.0f; x[1]=250.0f; x[2]=1.0f; x[3]=ac_pdr;
  x[4]=0.0f; x[5]=0.0f; x[6]=(float)ac_packets;
  x[7]=0.0f; x[8]=0.0f; x[9]=0.0f;

  // Link slot 2: BD
  x[10]=0.0f; x[11]=250.0f; x[12]=1.0f; x[13]=bd_pdr;
  x[14]=0.0f; x[15]=0.0f; x[16]=(float)bd_packets;
  x[17]=0.0f; x[18]=0.0f; x[19]=0.0f;

  // Spatial aggregate features.
  x[40]=2.0f;
  x[41]=max(ac_pdr,bd_pdr);
  x[42]=(ac_pdr+bd_pdr)*0.5f;
  x[43]=min(ac_pdr,bd_pdr);
  x[44]=fabsf(ac_pdr-bd_pdr);
  x[45]=fabsf(ac_pdr-bd_pdr)*0.70710678f;
}
