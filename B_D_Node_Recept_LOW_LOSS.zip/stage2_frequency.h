#pragma once
#include <Arduino.h>

struct Stage2FrequencyPoint {
  uint8_t channel;
  float pdr;
};

static inline Stage2FrequencyPoint stage2_make_point(uint8_t ch, float pdr) {
  Stage2FrequencyPoint p{ch,pdr};
  return p;
}
