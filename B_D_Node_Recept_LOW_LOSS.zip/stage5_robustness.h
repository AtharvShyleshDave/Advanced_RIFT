#pragma once
#include <Arduino.h>
#include <math.h>

static inline float stage5_confidence_margin(const float *p, int n) {
  float a=-1.0f,b=-1.0f;
  for(int i=0;i<n;i++){ if(p[i]>a){b=a;a=p[i];} else if(p[i]>b) b=p[i]; }
  return a-b;
}
