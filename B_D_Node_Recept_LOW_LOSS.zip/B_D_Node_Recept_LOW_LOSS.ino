#include <SPI.h>
#include <RF24.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>

#include "stage1_statistical.h"
#include "stage2_frequency.h"
#include "stage2b_controlled_frequency.h"
#include "stage3_spatial.h"
#include "stage4_fusion.h"
#include "stage5_robustness.h"

// ================================================================
// ESP32 #2 : NODE B + NODE D
// BD LOW-LOSS COMMISSIONING TEST
//
// Local link:
//
//        NODE B  ---------------->  NODE D
//
// Both radios are on the SAME ESP32.
// Therefore Node D is placed into RX mode BEFORE Node B transmits.
// ================================================================


// ================================================================
// Wi-Fi
// ================================================================

const char* SSID = "Redmi Note 13 5G";
const char* PASSWORD = "AtharvDave";

WebServer server(80);


// ================================================================
// nRF24 RADIO DEFINITIONS
// ================================================================

// Node B
// CE = GPIO4
// CSN = GPIO13
RF24 nodeB(4, 13);


// Node D
// CE = GPIO21
// CSN = GPIO22
RF24 nodeD(21, 22);


// ================================================================
// BD LINK CONFIGURATION
// ================================================================

// BD communication pipe.
//
// IMPORTANT:
// The previous code declared this as ADDR_AC but the actual
// BD test uses ADDR_BD. That caused the compiler error.
//
// The address value is kept unchanged.
const uint64_t ADDR_BD = 0xE7E7E7E703LL;


// Existing BD channel
const uint8_t CH_BD = 115;


// ESP32 #1 TinyML endpoint
const char* ESP1_ML_URL = "http://ac-node.local/api/ml_peer";


// ================================================================
// COMMISSIONING PARAMETERS
// ================================================================

const uint16_t PACKETS_PER_TEST = 30;
const uint16_t INTER_PACKET_DELAY_MS = 10;


// ================================================================
// STATISTICS
// ================================================================

uint16_t txAckOK = 0;
uint16_t rxReceived = 0;
uint16_t txFailed = 0;

float deliveryLoss = 100.0;


// ================================================================
// NRF24 CONFIGURATION
// ================================================================

void configureNRF(RF24& radio) {

  if (!radio.begin()) {
    Serial.println("ERROR: nRF24 initialization failed.");
    return;
  }

  // Maximum reliability / range configuration
  radio.setDataRate(RF24_250KBPS);

  radio.setPALevel(RF24_PA_MAX);

  // Auto acknowledgement
  radio.setAutoAck(true);

  // Maximum RF24 retry configuration
  radio.setRetries(15, 15);

  // Strong CRC
  radio.setCRCLength(RF24_CRC_16);

  // One-byte payload
  radio.setPayloadSize(1);

  // Start in TX / standby mode
  radio.stopListening();
}


// ================================================================
// SETUP
// ================================================================

void setup() {

  Serial.begin(115200);

  delay(500);

  Serial.println();
  Serial.println("========================================");
  Serial.println(" ESP32 #2 : NODE B + NODE D");
  Serial.println(" BD LOW-LOSS COMMISSIONING");
  Serial.println("========================================");


  // ------------------------------------------------
  // SPI
  // ------------------------------------------------

  // Shared SPI bus
  //
  // SCK  = GPIO18
  // MISO = GPIO19
  // MOSI = GPIO23
  //
  // CSN is handled independently by each RF24 object.
  SPI.begin();


  // ------------------------------------------------
  // Configure both nRF24 radios
  // ------------------------------------------------

  configureNRF(nodeB);
  configureNRF(nodeD);


  // ------------------------------------------------
  // Wi-Fi
  // ------------------------------------------------

  WiFi.begin(SSID, PASSWORD);

  Serial.print("Connecting to Wi-Fi");

  uint32_t wifiStart = millis();

  while (
    WiFi.status() != WL_CONNECTED &&
    millis() - wifiStart < 15000
  ) {

    delay(250);

    Serial.print(".");
  }


  if (WiFi.status() == WL_CONNECTED) {

    Serial.println();
    Serial.println("Wi-Fi Connected!");

    Serial.print("ESP32 #2 IP: ");
    Serial.println(WiFi.localIP());

  } else {

    Serial.println();
    Serial.println("Wi-Fi connection failed.");
    Serial.println("BD RF test will continue.");

  }


  // ------------------------------------------------
  // HTTP telemetry endpoint
  // ------------------------------------------------

  server.on("/api/telemetry", handleTelemetry);

  server.begin();


  // ------------------------------------------------
  // Startup information
  // ------------------------------------------------

  Serial.println();
  Serial.println("========================================");
  Serial.println(" ESP32 #2 : BD LOW-LOSS TEST");
  Serial.println(" NODE B  --->  NODE D");
  Serial.println(" 250 kbps | PA_MAX | AutoACK | Retry 15");
  Serial.printf(" BD channel : %u\n", CH_BD);
  Serial.printf(" BD address : 0x%llX\n", ADDR_BD);
  Serial.println("========================================");
}


// ================================================================
// BD TEST
// ================================================================

void runBDTest() {

  // Reset statistics
  txAckOK = 0;
  rxReceived = 0;
  txFailed = 0;


  // ==============================================================
  // STEP 1
  // Configure NODE D as receiver FIRST
  // ==============================================================

  nodeD.stopListening();

  nodeD.setChannel(CH_BD);

  nodeD.openReadingPipe(1, ADDR_BD);

  // Remove stale packets
  nodeD.flush_rx();

  // Enter RX mode
  nodeD.startListening();


  // Give the radio time to enter RX mode
  delay(100);


  // ==============================================================
  // STEP 2
  // Configure NODE B as transmitter
  // ==============================================================

  nodeB.stopListening();

  nodeB.setChannel(CH_BD);

  nodeB.openWritingPipe(ADDR_BD);


  // ==============================================================
  // STEP 3
  // Send packets
  // ==============================================================

  for (
    uint16_t i = 0;
    i < PACKETS_PER_TEST;
    i++
  ) {

    uint8_t payload = 0xB4;


    // ------------------------------------------------
    // Transmit
    // ------------------------------------------------

    bool ok = nodeB.write(
      &payload,
      sizeof(payload)
    );


    if (ok) {

      txAckOK++;

    } else {

      txFailed++;

    }


    // ------------------------------------------------
    // Immediately drain Node D
    // ------------------------------------------------

    while (nodeD.available()) {

      uint8_t receivedPayload;

      nodeD.read(
        &receivedPayload,
        sizeof(receivedPayload)
      );


      if (receivedPayload == 0xB4) {

        rxReceived++;

      }
    }


    // Allow HTTP server to respond
    server.handleClient();


    delay(INTER_PACKET_DELAY_MS);
  }


  // ==============================================================
  // FINAL RX DRAIN
  // ==============================================================

  delay(100);


  while (nodeD.available()) {

    uint8_t receivedPayload;

    nodeD.read(
      &receivedPayload,
      sizeof(receivedPayload)
    );


    if (receivedPayload == 0xB4) {

      rxReceived++;

    }
  }


  // Stop receiver
  nodeD.stopListening();


  // ==============================================================
  // DELIVERY LOSS
  // ==============================================================

  deliveryLoss =
    100.0 *
    (
      PACKETS_PER_TEST -
      min(txAckOK, PACKETS_PER_TEST)
    )
    /
    (float)PACKETS_PER_TEST;


  // ==============================================================
  // PRINT RESULTS
  // ==============================================================

  Serial.println();
  Serial.println("========================================");
  Serial.println("             BD TEST RESULT");
  Serial.println("========================================");

  Serial.printf(
    "Channel          : %u\n",
    CH_BD
  );

  Serial.printf(
    "Packets attempted: %u\n",
    PACKETS_PER_TEST
  );

  Serial.printf(
    "TX ACK success   : %u\n",
    txAckOK
  );

  Serial.printf(
    "TX failed        : %u\n",
    txFailed
  );

  Serial.printf(
    "RX received      : %u\n",
    rxReceived
  );

  Serial.printf(
    "Delivery loss    : %.2f %%\n",
    deliveryLoss
  );

  Serial.println("----------------------------------------");


  if (
    txAckOK == PACKETS_PER_TEST &&
    rxReceived == PACKETS_PER_TEST
  ) {

    Serial.println("RESULT: BD LINK CLEAN");

  }

  else if (
    txAckOK == PACKETS_PER_TEST
  ) {

    Serial.println(
      "RESULT: ACK SUCCESS BUT RX COUNT MISMATCH"
    );

  }

  else {

    Serial.println(
      "RESULT: BD LINK HAS REAL DELIVERY FAILURES"
    );

  }


  Serial.println("========================================");
}


// ================================================================
// MAIN LOOP
// ================================================================

void loop() {

  // HTTP server
  server.handleClient();


  // Run BD measurement
  runBDTest();


  // Send BD result to ESP32 #1
  postBDForTinyML();


  // Pause between tests
  delay(1000);
}


// ================================================================
// HTTP TELEMETRY ENDPOINT
// ================================================================

void handleTelemetry() {

  StaticJsonDocument<400> doc;


  doc["esp_id"] = 2;

  doc["link"] = "BD";

  doc["channel"] = CH_BD;

  doc["packets"] = PACKETS_PER_TEST;

  doc["tx_ack_ok"] = txAckOK;

  doc["tx_failed"] = txFailed;

  doc["rx_received"] = rxReceived;

  doc["delivery_loss_percent"] = deliveryLoss;


  String output;

  serializeJson(
    doc,
    output
  );


  server.sendHeader(
    "Access-Control-Allow-Origin",
    "*"
  );


  server.send(
    200,
    "application/json",
    output
  );
}


// ================================================================
// SEND BD DATA TO ESP32 #1
// ================================================================

void postBDForTinyML() {

  // No Wi-Fi = no HTTP upload
  if (WiFi.status() != WL_CONNECTED) {
    return;
  }


  HTTPClient http;


  // Start HTTP connection
  if (!http.begin(ESP1_ML_URL)) {
    return;
  }


  http.addHeader(
    "Content-Type",
    "application/json"
  );


  StaticJsonDocument<160> doc;


  doc["pdr"] =
    txAckOK /
    (float)PACKETS_PER_TEST;

  doc["packets"] =
    PACKETS_PER_TEST;

  doc["link"] =
    "BD";


  String body;


  serializeJson(
    doc,
    body
  );


  int code = http.POST(body);


  http.end();


  if (code > 0) {

    Serial.printf(
      "TinyML peer upload HTTP %d\n",
      code
    );

  }
}