#pragma once
#include <Arduino.h>

static inline bool stage2b_channel_valid(int ch) {
  return ch >= 0 && ch <= 125;
}

static inline uint8_t stage2b_clamp_channel(int ch) {
  if (ch < 0) return 0;
  if (ch > 125) return 125;
  return (uint8_t)ch;
}
