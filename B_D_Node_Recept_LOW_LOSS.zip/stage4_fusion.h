#pragma once
#include <Arduino.h>

static inline float stage4_fuse_pdr(float a, float b) {
  return 0.5f*(a+b);
}
